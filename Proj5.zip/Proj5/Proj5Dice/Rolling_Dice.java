import java.util.ArrayList;
/**
 * Select what happens when a dice is rolled
 *
 * Sierra Smith
 * @1.3618
 * @todo rolls array to make sure 50% or more is NOT 1
 */
public class Rolling_Dice
{
private Di dice;    
private int Rolls;
private int Type;
private int Target;
private int Total;
private int i;
private int array[];
private int score;
/**
 * Constructor for objects of class Rolling_Dice
 */
public Rolling_Dice(int Rolls, int Type, int Target)
    {
        if (Rolls <= 10 && Rolls >= 0){
                this.Rolls = Rolls;
            } else {
                System.out.println("Invalid number of Rolls please try again");
            }
        
        if (Type == 4 || Type == 6 || Type == 8 || Type == 10 || Type == 12 || Type == 20 || Type == 100) {
                this.Type = Type;
            } else {
                System.out.println("Invalid Dice Type please select again.");
            }
            
        if (Target <5 || Target > 30){
                 System.out.println("Sorry that is an invalid option, please try again");
            } else {
                this.Target = Target;
            }
        
    }

    /**
     * Reinput Rolls
     */
    public int numRolls (int Rolls)
    {
      if (Rolls <= 10 && Rolls >= 0){
                this.Rolls = Rolls;                
            } else {
                System.out.println("Invalid number of Rolls please try again");              
        }
        return Rolls;
    }
    
     /**
     * Reinput Dice type
     */
    public int numDice(int Type)
    {
        if (Type == 4 || Type == 6 || Type == 8 || Type == 10 || Type == 12 || Type == 20 || Type == 100) {
                this.Type = Type;
            } else {
                System.out.println("Invalid Dice Type please select again.");
            }
            return Type;
    }
    
     /**
     * reinput Target size
     */
    public int targetSize(int Target)
    {
       if (Target < 5 || Target > 30){
                System.out.println("Sorry that is an invalid option, please try again");
            } else {
                this.Target = Target;
            }
            return Type;
    }
    
     /**
     * count rolls
     */
    void countRolls()
    {
       int i = 0;
       dice = new Di(Type);
       while (i < this.Rolls){
           dice.rollDice();
           dice.land();
           if (dice.land() == dice.size()) {
               dice.rollDice();
               dice.land();
           }
           if (dice.land() == 1) {
               for (int row = 0; row < Rolls; row++) {
                   score = dice.land();
                   array[row] = score;
                }
           }                    
        }
        if ((array.length > (Rolls % 2))){ //division in half
            Total = 0;
        }
    }
    
    /**
     * view total
     */
     public int viewTotal()
    {
       return Total;
    }
    
     /**
     * did you get close?
     */
     void viewWin()
    {
       System.out.println("Your target was: " + Target);
       System.out.println("Your total was: " + Total);
       if (Total == Target){
           System.out.println("Congradulations! Your guess was correct!");
        }
    }
}
