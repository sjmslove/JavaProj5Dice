/**
 * Write a description of class Di here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Di
{
    // instance variables - replace the example below with your own
    /*
     * need math random rolls
     * 
     */
    private int size;
    private int roll;
    private int score;
    

    /**
     * Constructor for objects of class Di
     */
    public Di(int size)
    {
       this.size = size;
    }

    public int size()
    {
        return this.size;
    }
    
    public int land()
    {
        score = this.roll;
        return score;
    }
    
    void rollDice()
    {
        roll = (int)(Math.random()*size+1);
    }
}
